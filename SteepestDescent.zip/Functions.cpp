//
//  Functions.cpp
//  SteepestDescent
//
//  Created by ladmin on 06.06.13.
//  Copyright (c) 2013 Philipp Gloor. All rights reserved.
//


double function(double x) {
    return 3*x*x + 3;
}