Steepest Descent:

Programm to find minimum of any given function


To install boost on mac: 

get macports

install macports

restart

run sudo port -v selfupdate

install boost with:  sudo port install boost